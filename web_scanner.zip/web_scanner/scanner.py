#!/usr/bin/env python3
"""
Automated Web Security Scanner
Passive audit of a website's security headers, cookie flags and CORS config.
Sirf un sites par chalayein jinki aapko permission ho (ya demo sites jaise example.com).

Usage:
    python scanner.py https://example.com
    python scanner.py https://example.com --html report.html --json report.json
"""
import argparse
import json
import sys
from datetime import datetime

import requests

TIMEOUT = 10

# header -> (severity, why it matters, recommended value)
SECURITY_HEADERS = {
    "Strict-Transport-Security": (
        "High",
        "HTTPS downgrade / SSL-stripping attacks se bachata hai.",
        "max-age=31536000; includeSubDomains",
    ),
    "Content-Security-Policy": (
        "High",
        "XSS aur data injection attacks ko roakta hai.",
        "default-src 'self'",
    ),
    "X-Frame-Options": (
        "Medium",
        "Clickjacking se bachata hai (page ko iframe mein load hone se rokta hai).",
        "DENY ya SAMEORIGIN",
    ),
    "X-Content-Type-Options": (
        "Medium",
        "Browser ko MIME-sniffing karne se rokta hai.",
        "nosniff",
    ),
    "Referrer-Policy": (
        "Low",
        "Dusri sites ko URL ki sensitive info leak hone se rokta hai.",
        "strict-origin-when-cross-origin",
    ),
    "Permissions-Policy": (
        "Low",
        "Camera, mic, geolocation jaise browser features ko restrict karta hai.",
        "geolocation=(), camera=(), microphone=()",
    ),
}

LEAKY_HEADERS = ["Server", "X-Powered-By", "X-AspNet-Version"]

SEVERITY_POINTS = {"High": 20, "Medium": 10, "Low": 5}


def fetch(url, headers=None):
    return requests.get(url, headers=headers, timeout=TIMEOUT, allow_redirects=True)


def check_security_headers(resp):
    findings = []
    for name, (sev, why, rec) in SECURITY_HEADERS.items():
        value = resp.headers.get(name)
        if value is None:
            findings.append(
                {"check": name, "status": "MISSING", "severity": sev,
                 "detail": why, "recommendation": rec}
            )
        else:
            findings.append(
                {"check": name, "status": "OK", "severity": "Info",
                 "detail": value, "recommendation": ""}
            )
    # HSTS weak max-age
    hsts = resp.headers.get("Strict-Transport-Security", "")
    if hsts and "max-age" in hsts:
        try:
            age = int(hsts.split("max-age=")[1].split(";")[0])
            if age < 15552000:
                findings.append(
                    {"check": "HSTS max-age", "status": "WEAK", "severity": "Low",
                     "detail": f"max-age={age} bahut kam hai",
                     "recommendation": "Kam se kam 15552000 (6 mahine) rakhein"}
                )
        except ValueError:
            pass
    return findings


def check_info_leak(resp):
    findings = []
    for h in LEAKY_HEADERS:
        if h in resp.headers:
            findings.append(
                {"check": f"{h} header", "status": "EXPOSED", "severity": "Low",
                 "detail": f"Server info leak: {resp.headers[h]}",
                 "recommendation": "Ye header hata dein ya generic rakhein"}
            )
    return findings


def check_cookies(resp):
    findings = []
    raw = resp.raw.headers.getlist("Set-Cookie") if hasattr(resp.raw.headers, "getlist") else []
    for c in raw:
        name = c.split("=")[0]
        low = c.lower()
        missing = []
        if "secure" not in low:
            missing.append("Secure")
        if "httponly" not in low:
            missing.append("HttpOnly")
        if "samesite" not in low:
            missing.append("SameSite")
        if missing:
            findings.append(
                {"check": f"Cookie '{name}'", "status": "WEAK", "severity": "Medium",
                 "detail": "Flags missing: " + ", ".join(missing),
                 "recommendation": "Secure; HttpOnly; SameSite=Lax/Strict set karein"}
            )
    return findings


def check_cors(url):
    """Teen alag Origin bhej kar dekhte hain server kaise react karta hai."""
    findings = []
    tests = [
        ("Arbitrary origin", "https://evil-attacker.example"),
        ("Null origin", "null"),
    ]
    for label, origin in tests:
        try:
            r = fetch(url, headers={"Origin": origin})
        except requests.RequestException as e:
            findings.append(
                {"check": f"CORS ({label})", "status": "ERROR", "severity": "Info",
                 "detail": str(e), "recommendation": ""}
            )
            continue
        acao = r.headers.get("Access-Control-Allow-Origin")
        acac = r.headers.get("Access-Control-Allow-Credentials", "").lower()
        if acao == "*" and acac == "true":
            findings.append(
                {"check": f"CORS ({label})", "status": "VULNERABLE", "severity": "High",
                 "detail": "Wildcard origin + credentials allowed",
                 "recommendation": "Wildcard ke saath credentials kabhi allow na karein"}
            )
        elif acao == origin:
            sev = "High" if acac == "true" else "Medium"
            findings.append(
                {"check": f"CORS ({label})", "status": "VULNERABLE", "severity": sev,
                 "detail": f"Server ne Origin '{origin}' ko reflect kiya"
                           + (" (credentials ke saath)" if acac == "true" else ""),
                 "recommendation": "Origins ki strict allow-list use karein"}
            )
        elif acao == "*":
            findings.append(
                {"check": f"CORS ({label})", "status": "OPEN", "severity": "Low",
                 "detail": "Access-Control-Allow-Origin: * (public resource ho to theek)",
                 "recommendation": "Sensitive endpoints par wildcard na rakhein"}
            )
        else:
            findings.append(
                {"check": f"CORS ({label})", "status": "OK", "severity": "Info",
                 "detail": "Untrusted origin allow nahi hua", "recommendation": ""}
            )
    return findings


def check_https(url):
    findings = []
    if url.startswith("http://"):
        findings.append(
            {"check": "HTTPS", "status": "MISSING", "severity": "High",
             "detail": "Site plain HTTP par hai",
             "recommendation": "HTTPS enable karein aur HTTP se redirect karein"}
        )
    return findings


def score(findings):
    total = 100
    for f in findings:
        if f["status"] not in ("OK", "ERROR"):
            total -= SEVERITY_POINTS.get(f["severity"], 0)
    return max(total, 0)


def grade(s):
    return "A" if s >= 90 else "B" if s >= 75 else "C" if s >= 60 else "D" if s >= 40 else "F"


def scan(url):
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    resp = fetch(url)
    findings = []
    findings += check_https(resp.url)
    findings += check_security_headers(resp)
    findings += check_info_leak(resp)
    findings += check_cookies(resp)
    findings += check_cors(resp.url)
    s = score(findings)
    return {
        "target": url,
        "final_url": resp.url,
        "status_code": resp.status_code,
        "scanned_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "score": s,
        "grade": grade(s),
        "findings": findings,
    }


def print_report(r):
    print("=" * 64)
    print(f" Web Security Scan: {r['target']}")
    print(f" Time: {r['scanned_at']}   HTTP {r['status_code']}")
    print(f" Score: {r['score']}/100   Grade: {r['grade']}")
    print("=" * 64)
    for f in r["findings"]:
        icon = "[+]" if f["status"] == "OK" else "[!]"
        print(f"{icon} {f['check']:<32} {f['status']:<11} {f['severity']}")
        print(f"     {f['detail']}")
        if f["recommendation"]:
            print(f"     Fix: {f['recommendation']}")


def write_html(r, path):
    colors = {"High": "#c0392b", "Medium": "#e67e22", "Low": "#f1c40f", "Info": "#27ae60"}
    rows = ""
    for f in r["findings"]:
        c = colors.get(f["severity"], "#999")
        rows += (
            f"<tr><td>{f['check']}</td><td>{f['status']}</td>"
            f"<td style='color:{c};font-weight:bold'>{f['severity']}</td>"
            f"<td>{f['detail']}</td><td>{f['recommendation']}</td></tr>"
        )
    html = f"""<!doctype html><html><head><meta charset="utf-8">
<title>Security Scan Report</title>
<style>
body{{font-family:Arial,sans-serif;margin:30px;color:#222}}
table{{border-collapse:collapse;width:100%}}
th,td{{border:1px solid #ccc;padding:8px;text-align:left;font-size:14px}}
th{{background:#1f2a44;color:#fff}}
.score{{font-size:32px;font-weight:bold}}
</style></head><body>
<h1>Web Security Scan Report</h1>
<p><b>Target:</b> {r['target']}<br><b>Scanned:</b> {r['scanned_at']}</p>
<p class="score">Score: {r['score']}/100 &nbsp; Grade: {r['grade']}</p>
<table><tr><th>Check</th><th>Status</th><th>Severity</th><th>Detail</th><th>Recommendation</th></tr>
{rows}</table></body></html>"""
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(html)


def main():
    ap = argparse.ArgumentParser(description="Passive web security header/CORS scanner")
    ap.add_argument("url")
    ap.add_argument("--html", help="HTML report file path")
    ap.add_argument("--json", help="JSON report file path")
    a = ap.parse_args()
    try:
        r = scan(a.url)
    except requests.RequestException as e:
        print(f"Error: site tak pahunch nahi paye: {e}")
        sys.exit(1)
    print_report(r)
    if a.html:
        write_html(r, a.html)
        print(f"\nHTML report saved: {a.html}")
    if a.json:
        with open(a.json, "w", encoding="utf-8") as fh:
            json.dump(r, fh, indent=2)
        print(f"JSON report saved: {a.json}")


if __name__ == "__main__":
    main()
