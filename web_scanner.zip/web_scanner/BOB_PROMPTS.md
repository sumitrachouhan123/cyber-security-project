# IBM Bob Prompts: Automated Web Scanner

Bob mein ek naya folder `web-scanner` kholo aur ye prompts ek-ek karke paste karo.
Har prompt ke baad Bob ka output / screenshot lena mat bhoolna (submission ke liye proof).

---

## Prompt 1: Project banao

```
Create a Python project called "Automated Web Security Scanner".
It should take a website URL from the command line and passively audit it for:
1. Missing security headers: Strict-Transport-Security, Content-Security-Policy,
   X-Frame-Options, X-Content-Type-Options, Referrer-Policy, Permissions-Policy
2. Information-leaking headers: Server, X-Powered-By
3. Cookie flags: Secure, HttpOnly, SameSite
4. CORS misconfiguration: test with an arbitrary Origin and with Origin: null,
   and flag if the server reflects the origin or uses a wildcard with credentials
5. Whether the site uses HTTPS

Use the requests library. Give each finding a severity (High/Medium/Low),
calculate a score out of 100 and a letter grade, and print a clear console report
with a recommended fix for every issue.
```

## Prompt 2: Report

```
Add --html and --json command line options to the scanner.
The HTML report should have a table with colour-coded severity,
the overall score and grade, the target URL and scan time.
```

## Prompt 3: Review / security

```
Review scanner.py for bugs and error handling. Make sure it handles timeouts,
invalid URLs and SSL errors gracefully, and that it only sends normal GET requests
(passive scanning, no attacks).
```

## Prompt 4: Tests

```
Write unit tests with pytest for the scoring and header-checking functions
using mocked responses.
```

## Prompt 5: Documentation

```
Generate a README.md explaining what the tool does, how to install and run it,
example output, and a legal disclaimer that it must only be used on websites
you own or have permission to test.
```

---

## Demo ke liye safe targets

- `https://example.com`
- `https://httpbin.org`
- `https://neverssl.com` (HTTP wali site, HTTPS warning dikhane ke liye)
- Apni khud ki website

## Agar Bob atak jaye

Isi folder mein `scanner.py` poora kaam karne wala backup code hai. Use Bob mein
open karke bolo: "Review and improve this scanner" aur screenshot le lo.
