# Automated Web Security Scanner

IBM SkillBuild National Cybersecurity Bootcamp project (BharatCares x IBM).

**Author:** Sumitra Chouhan
**Roll No:** 2504030100056

## Overview

A Python command-line tool that passively audits a website for common
security misconfigurations and produces a scored report.

### Checks performed

| Category | What is checked |
|---|---|
| Transport | Site uses HTTPS |
| Security headers | HSTS, CSP, X-Frame-Options, X-Content-Type-Options, Referrer-Policy, Permissions-Policy |
| Information leakage | `Server`, `X-Powered-By`, `X-AspNet-Version` headers |
| Cookies | `Secure`, `HttpOnly`, `SameSite` flags |
| CORS | Reflected origin, `null` origin, wildcard with credentials |

Each finding has a severity (High / Medium / Low), and the site gets an
overall score out of 100 with a grade (A to F).

## Installation

```bash
pip install -r requirements.txt
```

## Usage

```bash
python scanner.py https://example.com
python scanner.py https://example.com --html report.html --json report.json
```

## Sample output

```
Score: 0/100   Grade: F
[!] Strict-Transport-Security   MISSING     High
[!] Content-Security-Policy     MISSING     High
[+] X-Frame-Options             OK          Info
[!] Cookie 'session'            WEAK        Medium
[!] CORS (Arbitrary origin)     VULNERABLE  High
```

A deliberately insecure local test server is included for demos:

```bash
python tests/mock_server.py &
python scanner.py http://127.0.0.1:8099 --html report.html
```

## How it was built with IBM Bob

The project was developed using IBM Bob. Prompts used are listed in
`BOB_PROMPTS.md` (project scaffolding, report generation, code review,
unit tests, documentation).

## Tech stack

Python 3, `requests`

## Legal disclaimer

This tool only sends normal GET requests (passive scanning). Use it only on
websites you own or have explicit permission to test.
